

<?php $__env->startSection('title', 'Login Page'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between">
  <h1>All Todos</h1>
  <h4>Hi there, <?php echo e(session('user-token')->name); ?> 👋</h4>
</div>

<div class="d-flex justify-content-between mb-3">
  <a class="btn btn-primary" href="/add-todo">Add</a>
    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>">Logout</a>
</div>
  
      <ul class="list-group">
      <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="list-group-item d-flex justify-content-between">
        <?php echo e($todo->title); ?>

        <a class="text-warning" href="<?php echo e("edit-todo/".$todo->id); ?>">Edit</a>
        
      </li>
      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\test-1\resources\views/dashboard.blade.php ENDPATH**/ ?>